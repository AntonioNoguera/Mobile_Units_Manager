package com.example.administradordeunidadesmviles_e2023

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.administradordeunidadesmviles_e2023.databinding.ActivityCapturaDeImagenesBinding
import com.google.firebase.storage.FirebaseStorage
import java.io.ByteArrayOutputStream

class captura_de_imagenes : AppCompatActivity() {
    private lateinit var binding:ActivityCapturaDeImagenesBinding
    val storage = FirebaseStorage.getInstance()
    val storageRef = storage.reference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCapturaDeImagenesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val btnCamara = findViewById<Button>(R.id.btnCapturar)



        btnCamara.setOnClickListener {
            startForResult.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        }

        val usuario = intent.getStringExtra("user")

        binding.btnContinuar.setOnClickListener{
            val intent = Intent(this, main_empleado::class.java)
            intent.putExtra("user",usuario)
            startActivity(intent)
            overridePendingTransition(R.anim.from_right_in, R.anim.from_left_out)


        }


    }

    private val startForResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
            result: ActivityResult ->
        if (result.resultCode == Activity.RESULT_OK){
            val intent = result.data
            val imageBitmap =  intent?.extras?.get("data") as Bitmap
            val imageView3 = findViewById<ImageView>(R.id.imageView3)
            imageView3.setImageBitmap(imageBitmap)

            val timestamp = System.currentTimeMillis()
            val nombreArchivo = "$timestamp.jpg"
            val baos = ByteArrayOutputStream()
            imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            val data = baos.toByteArray()
            val referenciaImagen = storageRef.child("Fotos/$nombreArchivo")
            referenciaImagen.putBytes(data)
                .addOnSuccessListener { taskSnapshot ->
                    // la imagen se cargó exitosamente
                    // puedes obtener la URL de descarga con taskSnapshot.metadata?.reference?.downloadUrl
                }
                .addOnFailureListener { exception ->
                    // hubo un error al cargar la imagen
                }

        }


    }

}